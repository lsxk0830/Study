using UnityEngine;

public class Script_17_03 :MonoBehaviour
{
    void Update()
    {
        Log.Print(Time.frameCount + " " + gameObject);
        //Debug.Log(Time.frameCount+" " + gameObject);
    }
}

public static class Log
{
    [System.Diagnostics.Conditional("ENABLE_DEBUG")]
    static public void Print(object message)
    {
        Debug.Log(message);
    }
}
