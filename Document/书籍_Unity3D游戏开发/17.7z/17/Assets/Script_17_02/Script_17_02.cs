using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public class Script_17_02 :MonoBehaviour
{
    ObjectPool<GameObject> m_ObjectPool;
    private void Start()
    {
        //创建缓存池，创建、获取、释放、销毁事件、默认于最大缓存池数量
        m_ObjectPool = new ObjectPool<GameObject>(Create, Get, Release, Destroy, true, 10, 20);
    }

    GameObject Create()
    {
        return new GameObject();
    }
    void Get(GameObject go)
    {
        go.SetActive(true);
    }
    void Release(GameObject go)
    {
        go.SetActive(false);
    }

    void Destroy(GameObject go)
    {
        go.SetActive(false);
    }

    List<GameObject> list = new List<GameObject>();
    private void Update()
    {
        if (Input.GetKeyUp(KeyCode.A))
        {
            list.Add(m_ObjectPool.Get());
        }
        if (Input.GetKeyUp(KeyCode.D))
        {
            //清除最后一个
            if (list.Count > 0)
            {
                int index = list.Count - 1;
                m_ObjectPool.Release(list[index]);
                list.RemoveAt(index);
            }
        }
    }
}
