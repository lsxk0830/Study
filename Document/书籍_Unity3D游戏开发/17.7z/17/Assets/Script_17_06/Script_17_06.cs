using UnityEngine;
using UnityEngine.Profiling;
public class Script_17_06 :MonoBehaviour
{
    private void OnGUI()
    {
        if (GUILayout.Button("<size=100>Start</size>"))
        {
            Profiler.logFile = $"{Application.persistentDataPath}/Script_17_06_log"; 
            Profiler.enableBinaryLog = true;
            Profiler.enabled = true;
            Profiler.maxUsedMemory = 256 * 1024 * 1024;
        }

        if (GUILayout.Button("<size=100>Stop</size>"))
        {
            Profiler.enabled = false;
            Profiler.logFile = "";
        }

        GUILayout.Label($"<size=30>{Profiler.logFile}</size>");
    }
}


