using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Profiling;

public class Script_17_04 :MonoBehaviour
{
    Recorder m_Recorder;
    void Start()
    {
        //遍历所有的SamplerName
        List<string> names = new List<string>();
        Sampler.GetNames(names);
        foreach (var name in names)
        {
            Debug.Log(name);
        }
        //记录Sampler的耗时
        var sampler = Sampler.Get("Sampler");
        m_Recorder = sampler.GetRecorder();
        if (m_Recorder.isValid)
        {
            m_Recorder.enabled = true;
        }
    }

    private void Update()
    {
        Debug.Log(" time: " + m_Recorder.elapsedNanoseconds);
    }
}


