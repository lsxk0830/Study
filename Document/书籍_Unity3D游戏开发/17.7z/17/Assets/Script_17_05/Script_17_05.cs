using UnityEngine;
using UnityEngine.Profiling;

public class Script_17_05 :MonoBehaviour
{
    public Texture2D texture;

    private void Start()
    {
        Debug.Log(Profiler.GetRuntimeMemorySizeLong(texture)); //out 86.1KB
    }
}


