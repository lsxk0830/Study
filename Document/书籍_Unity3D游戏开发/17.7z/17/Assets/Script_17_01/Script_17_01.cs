using System;
using UnityEngine;

public class Script_17_01 
{
    static public event Action onUpdate;
    static Internal s_Internal;
    static Script_17_01()
    {
        s_Internal = new GameObject("_Event_").AddComponent<Internal>();
        GameObject.DontDestroyOnLoad(s_Internal.gameObject);
    }
    class Internal : MonoBehaviour
    {
        private void Update()
        {
            onUpdate?.Invoke();
        }
    }
}
