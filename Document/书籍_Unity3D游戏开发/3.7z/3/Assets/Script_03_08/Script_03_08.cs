using System.Collections;
using UnityEngine;

public class Script_03_08 : MonoBehaviour
{
    private int m_CacheValue=-1;
    public void UpdateValue(int value)
    {
        Debug.Log($"第{Time.frameCount}帧尝试赋值{value}");
        if (m_CacheValue == -1)
        {
            StartCoroutine(Wait());
        }
        m_CacheValue = value;
    }

    IEnumerator Wait()
    {
        yield return new WaitForEndOfFrame();
        //用最后一次的m_CacheValue在进行耗时计算
        Debug.Log($"第{Time.frameCount}帧最终处理值{m_CacheValue}");
        m_CacheValue = -1;
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            //尝试进行多次赋值
            UpdateValue(2);
            UpdateValue(3);
        }
    }
}



