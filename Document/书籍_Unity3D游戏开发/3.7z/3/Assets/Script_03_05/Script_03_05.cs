using System;
using System.Collections.Generic;
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;

public class Script_03_05 : MonoBehaviour
{
    [Serializable]
    public class Data
    {
        public int Value = 1;
    }
    [SerializeReference]
    public List<Data> Item;

#if UNITY_EDITOR
    [CustomEditor(typeof(Script_03_05))]
    public class ScriptInsector : Editor
    {
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
            if (GUILayout.Button("添加数据"))
            {
                //这里创建了两种不同的数据
                Data data1 = new Data() { Value = 1 };
                Data data2 = new Data() { Value = 2 };
                //在这里添加引用
                // data1,data2虽然被添加了多次，但是只会被序列化1次
                (target as Script_03_05).Item = new List<Data>() {
                    data1,data1,data2,data2
                };
                //强制设置场景Dirty进行重新保存
                EditorUtility.SetDirty(target);
            }
        }
    }
#endif
}

