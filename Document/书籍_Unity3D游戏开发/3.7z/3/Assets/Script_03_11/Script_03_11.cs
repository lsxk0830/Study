using System;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class Script_03_11 : MonoBehaviour
{

    private void Start()
    {
       
        var source = Delay(1000, () => {
            Debug.Log("1秒后回调");
        });

        source.Cancel();
    }

    CancellationTokenSource Delay(int time, Action finish)
    {
        CancellationTokenSource source = new CancellationTokenSource();
        InternalDelay(time, source.Token, finish);
        return source;
    }
    async void InternalDelay(int time,CancellationToken token,Action finish)
    {
        try
        {
            await Task.Delay(time, token);
            finish?.Invoke();
        }
        catch (TaskCanceledException)
        {
        }
    }


 

}



