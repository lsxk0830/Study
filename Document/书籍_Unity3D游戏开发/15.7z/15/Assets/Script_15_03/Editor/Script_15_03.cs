using UnityEditor;
using UnityEngine;
public class Script_15_03 
{
    [MenuItem("Tool/Script_15_03")]
    static void Create()
    {
        //游戏对象依赖
        GameObject cube1 = GameObject.Find("Cube");
        foreach (var depend in EditorUtility.CollectDependencies(new Object[] { cube1 }))
        {
            var path = AssetDatabase.GetAssetPath(depend);
        }
        //游戏资源依赖
        foreach (var path in AssetDatabase.GetDependencies("Assets/Script_15_03/Resources/Cube.prefab"))
        {
            Debug.Log(path);
        } 
    }
}
