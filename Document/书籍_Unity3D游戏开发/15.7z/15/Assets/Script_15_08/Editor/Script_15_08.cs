using System.Collections.Generic;
using UnityEditor.Build;
using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.Rendering;

public class Script_15_08 : IPreprocessShaders
{
    ShaderKeyword A = new ShaderKeyword("A");
    ShaderKeyword B = new ShaderKeyword("B");


    public int callbackOrder { get { return 0; } }

    public void OnProcessShader(Shader shader, ShaderSnippetData snippet, IList<ShaderCompilerData> data)
    {

        if ("Unlit/Custom1" != shader.name)
        {
            return;
        }

        for (int i = data.Count - 1; i >= 0; --i)
        {
            //当组合中同时包含A和B的时候剥离这个shader
            if (data[i].shaderKeywordSet.IsEnabled(A) && data[i].shaderKeywordSet.IsEnabled(B))
            {
                data.RemoveAt(i);
            }
        }
    }
}
