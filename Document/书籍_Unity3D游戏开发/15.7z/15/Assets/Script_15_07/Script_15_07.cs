using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

public class Script_15_07 : MonoBehaviour
{
    public Text text;
    void Start()
    {
		//加载DLL文件
		Assembly assembly = Assembly.LoadFrom(Application.streamingAssetsPath +
			"/HotUpdate.dll");
		//获取某个类
		Type type = assembly.GetType("HotUpdate");
		//获取类中的某个方法
		MethodInfo mi = type.GetMethod("GetName");
		//反射调用GetName方法，并且获取返回值
		text.text = mi.Invoke(null, new object[] { }).ToString();
	}
}
