public class HotUpdate
{
	static public string GetName()
	{
		return "HotUpdate";
	}
}
