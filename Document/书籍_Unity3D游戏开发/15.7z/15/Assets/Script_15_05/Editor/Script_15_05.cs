using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
public class Script_15_05 
{
	[MenuItem("Tool/BuildAssetbundle2")]
	static void BuildAssetbundle()
	{
		List<AssetBundleBuild> builds = new List<AssetBundleBuild>();
		//构建 Cube Cube2 到ALL.unity3d中
		builds.Add(new AssetBundleBuild()
		{
			assetBundleName = "ALL.unity3d",
			assetNames = new string[] { "Assets/Script_15_05/Cube.prefab", "Assets/Script_15_05/Cube2.prefab" }
		});
		//构建 Cube3到Single.unity3d中
		builds.Add(new AssetBundleBuild()
		{
			assetBundleName = "Single.unity3d",
			assetNames = new string[] { "Assets/Script_15_05/Cube3.prefab"}
		});
		//构建公共依赖材质到Share.unity3d中
		builds.Add(new AssetBundleBuild()
		{
			assetBundleName = "Share.unity3d",
			assetNames = new string[] { "Assets/Script_15_05/Cube Material.mat" }
		});
		//构建AssetBundle
		BuildPipeline.BuildAssetBundles(Application.streamingAssetsPath, builds.ToArray(), BuildAssetBundleOptions.ChunkBasedCompression, BuildTarget.StandaloneOSX);
		//刷新
		AssetDatabase.Refresh();
		
	}
}
