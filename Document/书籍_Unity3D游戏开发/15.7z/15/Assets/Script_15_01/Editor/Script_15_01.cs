using UnityEditor;
using UnityEngine;

public class Script_15_01 
{
    [MenuItem("Tool/Script_15_01")]
    static void CreatPrefab()
    {
        var asset = new GameObject();
        PrefabUtility.SaveAsPrefabAsset(asset,"Assets/Script_15_01/go.prefab");
        Object.DestroyImmediate(asset);
    }
}
