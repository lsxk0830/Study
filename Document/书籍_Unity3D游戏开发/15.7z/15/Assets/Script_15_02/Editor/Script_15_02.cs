using UnityEditor;
using UnityEngine;
public class Script_15_02 
{
    [MenuItem("Tool/Script_15_02")]
    static void Create()
    {
        //创建游戏对象
        var asset = new GameObject();
        asset.name = "MyGameObject";

        //实例化Prefab
        var goAsset = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Script_15_01/go.prefab");
        var goinHierarchy = Object.Instantiate<GameObject>(goAsset);
        goinHierarchy.name = "MyGameObject2";

        //创建Prefab
        var prefabinHierarchy =  PrefabUtility.InstantiatePrefab(goAsset);
        prefabinHierarchy.name = "MyGameObject3";
    }
}
