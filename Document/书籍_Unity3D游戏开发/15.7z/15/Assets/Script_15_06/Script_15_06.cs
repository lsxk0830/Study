using System.IO;
using UnityEngine;

public class Script_15_06 : MonoBehaviour
{
    void Start()
    {
		AssetBundle assetbundle = AssetBundle.LoadFromFile(Path.Combine(Application.
					streamingAssetsPath, "StreamingAssets"));
		AssetBundleManifest manifest = assetbundle.LoadAsset<AssetBundleManifest>
			("AssetBundleManifest");

		//加载AB前，需要加载依赖的Bundle依赖的AB
		foreach (var item in manifest.GetAllDependencies("all.unity3d"))
		{
			AssetBundle.LoadFromFile(Path.Combine(Application.streamingAssetsPath,
				item));
		}
		//读取Bundle
		assetbundle = AssetBundle.LoadFromFile(Path.Combine(Application.
			streamingAssetsPath, "all.unity3d"));
		//从Bundle中读取资源
		GameObject prefab = assetbundle.LoadAsset<GameObject>("Cube");
		//实例化资源
		Instantiate<GameObject>(prefab);

		
	}
}
