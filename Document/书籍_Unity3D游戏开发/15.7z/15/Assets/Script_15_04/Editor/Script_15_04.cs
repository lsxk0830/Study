using UnityEditor;
using UnityEngine;
public class Script_15_04 
{
	[MenuItem("Tool/BuildAssetbundle")]
	static void BuildAssetbundle()
	{
		//构建Assetbundle
		BuildPipeline.BuildAssetBundles(Application.streamingAssetsPath, BuildAssetBundleOptions.
			ChunkBasedCompression, BuildTarget.StandaloneOSX);
		//刷新
		AssetDatabase.Refresh();
	}
}
