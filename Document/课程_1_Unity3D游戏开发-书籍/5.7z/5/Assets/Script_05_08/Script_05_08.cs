using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Script_05_08 : MonoBehaviour
{
    public VisualTreeAsset ItemAsset;
    void Start()
    {
        UIDocument document = GetComponent<UIDocument>();
        var root = document.rootVisualElement;

        //准备数据阶段
        const int itemCount = 10000;
        List<string> items = new List<string>(itemCount);
        for (int i = 0; i <= itemCount; i++)
            items.Add($"我是第{i}个<sprite=3>");

        ListView listview = root.Q<ListView>();

        Func<VisualElement> makeItem = () =>
        {
            //出现到屏幕中克隆对象
            return ItemAsset.CloneTree(); 
        };

        Action<VisualElement, int> bindItem = (e, i) =>
        {
            //屏幕中对象已经准备好开始刷新数据
            e.Q<Label>().text = listview.itemsSource[i].ToString();
        };

        listview.selectedIndicesChanged += (indexes) => {
            //选择某个元素调用
            foreach (var index in indexes)
            {
                Debug.Log($"第{index}个被选择了！");
            }
        };
        //设置每个Item的固定高度
        listview.fixedItemHeight = 100;
        //设置原始数据
        listview.itemsSource = items;
        listview.makeItem = makeItem;
        listview.bindItem = bindItem;
    }
}
