#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.UIElements;
#endif
using UnityEngine;
using UnityEngine.UIElements;
using System.Collections.Generic;
public class Script_05_18 : MonoBehaviour
{
    [System.Serializable]
    public class Data
    {
        public float a;
        public int b;
    }
    public int MyValue;
    public Vector2 MyPosition;
    public GameObject MyGameObject;
    public List<Data> MyData;
}

#if UNITY_EDITOR
[CustomEditor(typeof(Script_05_18))]
public class Script_05_18Editor : Editor
{
    public override VisualElement CreateInspectorGUI()
    {
        VisualElement inspector = new VisualElement();
        VisualTreeAsset visualTree = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/Script_05_18/Script_05_18_Template.uxml");
        visualTree.CloneTree(inspector);

        inspector.Q<Button>().clicked += () =>
        {
            Debug.Log("点击按钮");
        };

        return inspector;
    }
}
#endif



