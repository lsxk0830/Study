using UnityEngine;
using UnityEngine.UIElements;

public class Script_05_14 : MonoBehaviour
{
    VisualElement m_Image;
    void Start()
    {
        UIDocument document = GetComponent<UIDocument>();
        var root = document.rootVisualElement;
        m_Image = root.Q<VisualElement>();
        m_Image.RegisterCallback<PointerDownEvent>(OnPointerDown);
        m_Image.RegisterCallback<PointerMoveEvent>(OnPointerMove);
        m_Image.RegisterCallback<PointerUpEvent>(OnPointerUp);
    }
    bool m_Moving = false;
    private void OnPointerDown(PointerDownEvent evt)
    {
        m_Moving = true;
    }
    private void OnPointerMove(PointerMoveEvent evt)
    {
        if (m_Moving)
        {
            var pos = new Vector2(Input.mousePosition.x, Screen.height - Input.mousePosition.y);
            //转换自适应后的UI坐标
            pos = RuntimePanelUtils.ScreenToPanel(m_Image.panel, pos);
            //图片宽高是200，这里需要取中心点
            pos.x -= 200f/ 2f;
            pos.y -= 200f/ 2f;
            //设置坐标
            m_Image.transform.position = pos;
        }
    }

    private void OnPointerUp(PointerUpEvent evt)
    {
        m_Moving = false;
    }
}
