using UnityEngine;
using UnityEngine.UIElements;

public class Script_05_04 : MonoBehaviour
{
    public Sprite sprite;
    void Start()
    {
        UIDocument document = GetComponent<UIDocument>();
        var root = document.rootVisualElement;
        var visualElement = root.Q<VisualElement>("image");
        visualElement.style.backgroundImage = new StyleBackground(sprite);
    }
}
