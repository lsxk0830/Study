using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Script_05_05 : MonoBehaviour
{
    void Start()
    {
        UIDocument document = GetComponent<UIDocument>();
        var root = document.rootVisualElement;

        //处理Button组件
        var button = root.Q<Button>();
        button.clicked += () =>
        {
            Debug.Log("Button Click!");
        };

        //处理Toggle组件
        var toggle = root.Q<Toggle>();
        toggle.RegisterValueChangedCallback((value) => {
            Debug.Log($"toggle valueChanged : {value}");
        });

        //处理Scroller组件
        var scroller = root.Q<Scroller>();
        scroller.lowValue = 0; //最小值
        scroller.highValue = 100; //最大值
        scroller.valueChanged += (value) =>
        {
            Debug.Log($"scroller valueChanged : {value}");
        };

        var textField = root.Q<TextField>();
        textField.isDelayed = true;//输入完毕后统一回调
        textField.RegisterValueChangedCallback((value) => {
            Debug.Log($"textField valueChanged : {value.newValue}");
        });

        //处理Slider组件
        var slider = root.Q<Slider>("mySlider");
        slider.lowValue = 0;
        slider.highValue = 100;
        slider.RegisterValueChangedCallback((value) => {
            Debug.Log($"slider valueChanged : {value}");

        });

        //处理MinMaxSlider组件
        var minMaxSlider =root.Q<MinMaxSlider>("myMinMaxSlider");
        minMaxSlider.minValue = 0;
        minMaxSlider.maxValue = 100;
        minMaxSlider.RegisterValueChangedCallback((value) => {
            Debug.Log($"minMaxSlider valueChanged : {value.newValue}");
        });

        //处理DropdownField组件
        var dropdownField = root.Q<DropdownField>();
        dropdownField.choices = new List<string>() { "选项1", "选项2", "选项3" };
        dropdownField.value = dropdownField.choices[1];
        dropdownField.RegisterValueChangedCallback((value) =>
        {
            Debug.Log($"dropdownField valueChanged : {value.newValue}");
        });

        //动态设置枚举和监听
        MyEnmu myEnmu = MyEnmu.B;
        //处理EnumField组件
        var enumField = root.Q<EnumField>();
        enumField.Init(myEnmu);
        enumField.RegisterValueChangedCallback((value) => {

            Debug.Log($"enumField valueChanged : {value.newValue}");
        });
    }
    //添加一个自定义枚举
    public enum MyEnmu
    {
        A,B,C
    }
}
