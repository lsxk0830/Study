using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Script_05_09 : MonoBehaviour
{
    public VisualTreeAsset ItemAsset;
    void Start()
    {
        UIDocument document = GetComponent<UIDocument>();
        var root = document.rootVisualElement;

        //准备数据阶段
        const int itemCount = 10000;
        List<string> items = new List<string>(itemCount);
        for (int i = 0; i <= itemCount; i++)
            items.Add($"我是第{i}个<sprite=3>");

        ListView listview = root.Q<ListView>();

        Func<VisualElement> makeItem = () =>
        {
            //出现到屏幕中克隆对象
            return ItemAsset.CloneTree(); 
        };

        //关掉Image的选择事件
        listview.selectionType = SelectionType.None;
        Action<VisualElement, int> bindItem = (e, i) =>
        {
            //屏幕中对象已经准备好开始刷新数据
            var label = e.Q<Label>();
            var button = e.Q<Button>("button");
            label.text = listview.itemsSource[i].ToString();
            //因为button对象是循环使用的，所以每次要清空之前的监听
            button.clickable = null;
            button.clicked += () =>
            {
                Debug.Log($"点击了第{i}个按钮对象");
            };
        };



        //设置每个Item的固定高度
        listview.fixedItemHeight = 100;
        //设置原始数据
        listview.itemsSource = items;
        listview.makeItem = makeItem;
        listview.bindItem = bindItem;
    }
}
