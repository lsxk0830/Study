using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public class Script_05_17: EditorWindow
{
    [MenuItem("UIToolkit/Script_05_17")]
    public static void ShowExample17()
    {
        EditorWindow wnd = GetWindow<Script_05_17>();
        wnd.titleContent = new GUIContent("ShowExample17");
    }
    public void CreateGUI()
    {

        var visualTree = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/Script_05_17/Script_05_17_Template.uxml");
        rootVisualElement.Add(visualTree.Instantiate());

        rootVisualElement.Q<Button>().clicked += () => {
            Debug.Log("click");
        };
        rootVisualElement.Q<Toggle>().RegisterValueChangedCallback((change) => {
            Debug.Log(change.newValue);
        });

        IMGUIContainer iMGUIContainer = rootVisualElement.Q<IMGUIContainer>();
        iMGUIContainer.onGUIHandler = () =>
        {
            GUILayout.Label("Title");
            GUILayout.Button("我是IMGUI");
        };
    }
}

  

   
