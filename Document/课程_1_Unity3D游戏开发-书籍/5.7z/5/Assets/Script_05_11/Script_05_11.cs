using UnityEngine;
using UnityEngine.UIElements;

public class Script_05_11 : MonoBehaviour
{
    void Start()
    {
        UIDocument document = GetComponent<UIDocument>();
        var root = document.rootVisualElement;
        var visualTreeAsset = Resources.Load<VisualTreeAsset>("Script_05_11_Item");
        var template = visualTreeAsset.CloneTree();
        root.Add(template);//克隆到Hierarchy中
        template.Q<Label>().text = "更换文字";
    }
}
