using SQLite;
public class Hero
{
	public int ID { get; set; }
	public string Name { get; set; }
	public float Value { get; set; }
	public static Hero Get(SQLiteConnection db, int id)
	{
		return db.Table<Hero>().Where(s => s.ID == id).First();
	}
}
