using SQLite;
public class Item
{
	public int ID { get; set; }
	public string Name { get; set; }
	public float Value { get; set; }
	public static Item Get(SQLiteConnection db, int id)
	{
		return db.Table<Item>().Where(s => s.ID == id).First();
	}
}
