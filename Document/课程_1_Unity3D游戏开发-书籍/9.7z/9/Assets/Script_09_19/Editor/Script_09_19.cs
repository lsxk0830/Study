using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Xml;
using UnityEditor;
using OfficeOpenXml;
using SQLite;
using System.Text;

public class Script_09_19
{
	[MenuItem("Generate/ExcleToSQLite")]
    async static void GenerateCode()
	{
        string dir = Application.dataPath + "/Script_09_19/Excel";
        var databasePath = Path.Combine(Application.streamingAssetsPath, "Excel.db");

        if (File.Exists(databasePath))
            File.Delete(databasePath);
        //创建数据库
        var db = new SQLiteAsyncConnection(databasePath);

        foreach (var path in Directory.GetFiles(dir, "*.xlsx"))
        {
            using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (ExcelPackage excel = new ExcelPackage(fs))
                {
                    ExcelWorksheets workSheets = excel.Workbook.Worksheets;
                    //遍历所有worksheets
                    for (int i = 1; i <= workSheets.Count; i++)
                    {
                        ExcelWorksheet workSheet = workSheets[i];
                        int colCount = workSheet.Dimension.End.Column;
                        string tableName = workSheet.Name;
                        //生成C#代码
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine($"using SQLite;");
                        sb.AppendLine($"public class {tableName}");
                        sb.AppendLine("{");
                        string[] value = new string[colCount];
                        
                        for (int col = 1; col <= colCount; col++)
                        {
                            //读取每个格子中的数据
                            var valueType = workSheet.Cells[1, col].Text ?? "";
                            var property = workSheet.Cells[2, col].Text ?? "";
                            value[col-1] = $"{property} {valueType}";
                            sb.AppendLine($"\tpublic {valueType} {property} {{ get; set; }}");
                        }
                        sb.AppendLine($"\tpublic static {tableName} Get(SQLiteConnection db, int id)");
                        sb.AppendLine("\t{");
                        sb.AppendLine($"\t\treturn db.Table<{tableName}>().Where(s => s.ID == id).First();");
                        sb.AppendLine("\t}");
                        sb.AppendLine("}");
                        //生成数据库
                        await db.ExecuteAsync($"create table {tableName}({string.Join(',', value)})");
                        //生成代码
                        File.WriteAllText($"{Application.dataPath}/Script_09_19/{tableName}.cs", sb.ToString());
                        for (int row = 3, count = workSheet.Dimension.End.Row; row < count; row++)
                        {
                            value = new string[colCount];
                            for (int col = 1; col <= colCount; col++)
                            {
                                var valueType = workSheet.Cells[1, col].Text ?? "";
                                //读取每个格子中的数据
                                var text = workSheet.Cells[row, col].Text ?? "";
                                value[col - 1] = valueType == "string"? ("\"" +text + "\""):text;
                            }
                            await db.ExecuteAsync($"insert into {tableName} values ({string.Join(',', value)})");
                        }
                    }
                }
            }
        }
        await db.CloseAsync();
        AssetDatabase.Refresh();
    }
}
