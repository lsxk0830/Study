using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using RazorEngine;
using RazorEngine.Templating;
using System.IO;

public class Script_09_21
{
    [MenuItem("Generate/Normal")]
    static void GenerateNormal()
    {

        string template =
            "public class @Model.Name\n" +
            "{\n" +
            "\tpublic int @Model.Name1=@Model.Value1\n" +
            "\tpublic int @Model.Name2=@Model.Value2;\n" +
            "}\n";

        var Hero = Engine.Razor.RunCompile(template, "templateKey", null, new { Name = "Hero", Name1 = "a", Name2 = "b", Value1 = 1, Value2 = 2 });
        var Item = Engine.Razor.RunCompile(template, "templateKey", null, new { Name = "Item", Name1 = "c", Name2 = "d", Value1 = 3, Value2 = 4 });
        Debug.Log(Hero);
        Debug.Log(Item);
    }

    [MenuItem("Generate/Foreach")]
    static void GenerateForeach()
    {
        string template =
        "public class @Model.Name\n" +
        "{\n" +
            "@foreach (var data in Model.list)\n" +
            "{\n" +
                "if (data.Type==\"int\")\n" +
                "{" +
                    "@:\t\t public @(data.Type) @(data.Name) = @(data.Value);\n" +
                "}" +
            "}" +
        "}\n";
       
        List<object> Herolist = new List<object>()
        {
            new { Type="int", Name="a",Value="100"},
            new { Type="float", Name="b",Value="2.0f"},
            new { Type="int", Name="c",Value="2000"},
        };
      
        var Hero = Engine.Razor.RunCompile(template, "templateKey",null, new {Name="Hero",list = Herolist });
        Debug.Log(Hero);
    }

    [MenuItem("Generate/File")]
    static void GenerateFile()
    {
       
        List<object> Herolist = new List<object>()
        {
            new { Type="int", Name="a",Value="100"},
            new { Type="float", Name="b",Value="2.0f"},
            new { Type="int", Name="c",Value="2000"},
        };
        //读取模板
        string templateFile = $"{Application.dataPath}/Script_09_21/Temp.txt";
        var HeroFile = Engine.Razor.RunCompile(File.ReadAllText(templateFile), "templateKey", null, new { NameSpace="My" ,Name = "Hero", list = Herolist });

        //写入类文件
        string HeroFilePath = $"{Application.dataPath}/Script_09_21/Hero.cs";
        File.WriteAllText(HeroFilePath, HeroFile);
    }
}
