namespace My
{
    public class Hero
    {
                public int a = 100;
                public int c = 2000;
    }
}
