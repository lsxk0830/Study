using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Text;

public class Script_09_11 : MonoBehaviour
{
    void Start()
    {
        string dir = Application.dataPath + "/Script_09_11/Dir/";
        //如果目录存在删除它并且重新创建
        if (Directory.Exists(dir))
            Directory.Delete(dir,true);
        Directory.CreateDirectory(dir);

        List<string> lines = new List<string>()
        {
            "第一行文本",
            "第二行文本"
        };
        //按行写入文本
        string filePath = Path.Combine(dir, "line.txt");
        File.WriteAllLines(filePath, lines);
        //按行读取文本
        foreach (var line in File.ReadAllLines(filePath))
            Debug.Log(line);


        StringBuilder sb = new StringBuilder();
        sb.AppendLine("第一行");
        sb.AppendLine("第二行");
        //按内容写入文本
        filePath = Path.Combine(dir, "txt.txt");
        File.WriteAllText(filePath, sb.ToString());
        //按内容读取文本
        Debug.Log(File.ReadAllText(filePath));

    }
}
