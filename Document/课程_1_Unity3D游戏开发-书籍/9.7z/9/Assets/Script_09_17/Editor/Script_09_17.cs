using UnityEngine;
using System.IO;
using System.Xml;
using UnityEditor;
using Newtonsoft.Json;

public class Script_09_17
{
	[MenuItem("XML/ToJson")]
	static void XmlToJson()
	{
		string xmlPath = Path.Combine(Application.streamingAssetsPath, "test.xml");

		XmlDocument doc = new XmlDocument();
		doc.LoadXml(File.ReadAllText(xmlPath));

		//XML转json
		string json = JsonConvert.SerializeXmlNode(doc);
		Debug.Log(json);

		//json转xml
		string xml = JsonConvert.DeserializeXNode(json).ToString();
		Debug.Log(xml);
	}
}
