using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script_09_05 : MonoBehaviour
{
    void Start()
    {
        //将数据先填充到类对象中
        Data data = new Data();
        data.name = "Data";
        data.subData.Add(new SubData()
        {
            intValue = 1,
            boolValue = true,
            floatValue =
            0.1f,
            stringValue = "one"
        });
        data.subData.Add(new SubData()
        {
            intValue = 2,
            boolValue = true,
            floatValue =
            0.1f,
            stringValue = "two"
        });

        //将类对象转成字符串
        string json = JsonUtility.ToJson(data);
        Debug.Log(json);

        //将字符串还原成类对象
        data = JsonUtility.FromJson<Data>(json);
        Debug.Log($"name = {data.name}");
        foreach (var item in data.subData)
        {
            Debug.Log($"intValue = {item.intValue} boolValue = {item.boolValue} floatValue = {item.floatValue} stringValue = { item.stringValue}");
        }
    }

    [Serializable]
    public class Data
    {
        public string name;
        public List<SubData> subData = new List<SubData>();
    }

    [Serializable]
    public class SubData
    {
        public int intValue;
        public bool boolValue;
        public float floatValue;
        public string stringValue;
    }
}
