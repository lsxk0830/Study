using System.IO;
using System.Linq;
using SQLite;
using UnityEngine;
using UnityEditor;

public class Script_09_03
{
    public class Data
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    [MenuItem("SQLite/Create")]
    static void Test()
    {
        Create();
    }

    async static void Create()
    {
        var databasePath = Path.Combine(Application.streamingAssetsPath, "MyData.db");
        //创建数据库
        var db = new SQLiteAsyncConnection(databasePath);
        await db.CreateTableAsync<Data>();

        for (int i = 0; i < 100; i++)
        {
            var data = new Data()
            {
                Id = i,
                Name = "Myname " + i.ToString()
            };
            //写入数据
            await db.InsertAsync(data);
        }
    }
}
