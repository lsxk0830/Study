using System.IO;
using UnityEngine;
using UnityEngine.UI;
using SQLite;

public class Script_09_04 : MonoBehaviour
{

    public class Data
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public Text text;

    void Start()
    {

        var databasePath = Path.Combine(Application.streamingAssetsPath, "MyData.db");

#if UNITY_ANDROID && !UNITY_EDITOR
        UnityEngine.Networking.UnityWebRequest www = UnityEngine.Networking.UnityWebRequest.Get(databasePath);
        www.SendWebRequest();
        while (!www.isDone) { }
        databasePath = Path.Combine(Application.persistentDataPath, "MyData.db");
        File.WriteAllBytes(databasePath, www.downloadHandler.data);
#endif

        //读取数据库
        var db = new SQLiteConnection(databasePath);
        //读取Data表中ID为18的数据
        var query = db.Table<Data>().Where(s => s.Id == 18);
        //将结果保存在数组中
        var result =  query.ToList();

        //result = db.Query<Data>("select * from Data where Id = ?", 18);
        //最终显示出来
        foreach (var s in result)
        {
            text.text = $"id = {s.Id} name = {s.Name}";
        }
    }
}
