using System.IO;
using SQLite;
using UnityEngine;
using UnityEngine.UI;

public class Script_09_20 : MonoBehaviour
{
    public Text HeroText;
    public Text ItemText;
    void Start()
    {

        var databasePath = Path.Combine(Application.streamingAssetsPath, "Excel.db");

#if UNITY_ANDROID && !UNITY_EDITOR
        UnityEngine.Networking.UnityWebRequest www = UnityEngine.Networking.UnityWebRequest.Get(databasePath);
        www.SendWebRequest();
        while (!www.isDone) { }
        databasePath = Path.Combine(Application.persistentDataPath, "MyData.db");
        File.WriteAllBytes(databasePath, www.downloadHandler.data);
#endif

        //读取数据库
        var db = new SQLiteConnection(databasePath);
        //通过生成的类直接读取数据
        var hero = Hero.Get(db, 1);
        var item = Item.Get(db, 2);
        HeroText.text = $"id = {hero.ID} name={hero.Name} value ={hero.Value}";
        ItemText.text = $"id = {item.ID} name={item.Name} value ={item.Value}";
    }
}
