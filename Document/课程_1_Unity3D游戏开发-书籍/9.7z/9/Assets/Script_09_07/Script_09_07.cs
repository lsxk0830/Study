using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

public class Script_09_07 : MonoBehaviour
{
    void Start()
    {
        string json = "{\"name\":\"Data\",\"list\":[\"1\",\"2\"]}";
        JObject o = JObject.Parse(json);
        string name = (string)o["name"];

        List<string> list = o["list"].Select(t => (string)t).ToList();

        Debug.Log(name);
        foreach (var item in list)
        {
            Debug.Log(item);
        }
    }
}
