using UnityEngine;
using System.IO;
using System;
using System.Text;

public class Script_09_12 : MonoBehaviour
{
    void Start()
    {
        string dir = Application.dataPath + "/Script_09_12/Dir/";
        //如果目录存在删除它并且重新创建
        if (Directory.Exists(dir))
            Directory.Delete(dir,true);
        Directory.CreateDirectory(dir);

        string filePath = Path.Combine(dir, "txt.txt");
        //创建文件
        using (FileStream fs = File.Create(filePath))
        {
            for (int i = 0; i < 10; i++)
            {
                string content = $"number {i}" + Environment.NewLine; 
                byte[] info = Encoding.UTF8.GetBytes(content);
                fs.Write(info, 0, info.Length);
            }
            fs.Flush();
        }

        //如果文件存在原有文件基础上继续写入
        //如果文件不存在创建文件
        using (FileStream fs = File.Open(filePath,FileMode.OpenOrCreate))
        {
            //将流的起始点放到文件最后
            fs.Seek(0, SeekOrigin.End);
            //继续写入文件
            for (int i = 10; i < 20; i++)
            {
                string content = $"number {i}"+Environment.NewLine;
                byte[] info = Encoding.UTF8.GetBytes(content);
                fs.Write(info, 0, info.Length);
            }
        }

        //读文件
        using (FileStream fs = File.OpenRead(filePath))
        {
            // 一次读取buffer数组的10字节
            byte[] buffer = new byte[10];
            int readLen;
            while ((readLen = fs.Read(buffer, 0, buffer.Length)) > 0)
            {
                Debug.Log(Encoding.UTF8.GetString(buffer, 0, readLen));
            }
        }
    }
}
