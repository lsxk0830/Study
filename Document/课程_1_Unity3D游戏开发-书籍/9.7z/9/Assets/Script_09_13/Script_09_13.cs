using UnityEngine;
using System.IO;

public class Script_09_13 : MonoBehaviour
{
    void Start()
    {
        //可读写目录
        string writePath = Path.Combine(Application.persistentDataPath, "test.txt");
        File.WriteAllText(writePath, "写入内容");
        Debug.Log(writePath);

        //resources 只读目录
        string resourcesTxt = Resources.Load<TextAsset>("test").text;
        //streamingAssets 只读目录
        string streamingAssetsTxt = File.ReadAllText(Path.Combine(Application.
            streamingAssetsPath, "test.txt"));
        string writeTxt = File.ReadAllText(writePath);
        //输出内容
        Debug.Log($"{resourcesTxt} {streamingAssetsTxt} {writeTxt}");
    }
}
