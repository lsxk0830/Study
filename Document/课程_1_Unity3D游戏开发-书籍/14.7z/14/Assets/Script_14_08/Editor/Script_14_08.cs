using UnityEditor;
using UnityEditor.EditorTools;
using UnityEngine;

[EditorTool("Camera Tool", typeof(Camera))]
class Script_14_08 : EditorTool
{
    public override GUIContent toolbarIcon => new GUIContent("自定义");
    public override void OnToolGUI(EditorWindow window)
    {
        if (!(window is SceneView sceneView))
            return;
        Handles.BeginGUI();
        using (new GUILayout.HorizontalScope())
        {
            using (new GUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (GUILayout.Button("按钮"))
                {
                }
            }
            GUILayout.FlexibleSpace();
        }
        Handles.EndGUI();
    }
}
