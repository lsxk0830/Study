using UnityEngine;

#if UNITY_EDITOR
[ExecuteInEditMode]
public class Script_14_12 : MonoBehaviour
{
	void OnGUI()
	{
		if (!Application.isPlaying)
		{
			if (GUILayout.Button("Click"))
			{
				Debug.Log("click!!!");
			}
			GUILayout.Label("Hello World!!!");
		}
	}
}
#endif
