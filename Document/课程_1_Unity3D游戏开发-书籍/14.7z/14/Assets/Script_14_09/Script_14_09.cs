using UnityEngine;

class Script_14_09 : MonoBehaviour
{
	//选中时绘制
	void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.red;
		//画线
		Gizmos.DrawLine(transform.position, Vector3.one);
		//立方体
		Gizmos.DrawCube(Vector3.one, Vector3.one);
	}

	//一直绘制
	void OnDrawGizmos()
	{
		Gizmos.DrawSphere(transform.position, 1);
	}
}
