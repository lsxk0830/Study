using UnityEditor;
using UnityEngine;

public class Script_14_03 : AssetPostprocessor
{
    //导入模型前事件
    void OnPreprocessModel()
    {
        //通过脚本自动将模型的材质导入剥离
        if (assetPath.Contains("@"))
        { 
            ModelImporter modelImporter = assetImporter as ModelImporter;
            modelImporter.materialImportMode = ModelImporterMaterialImportMode.None;
        }
    }

    //导入贴图前事件
    void OnPreprocessTexture()
    {
        //通过脚本自动设置贴图的格式
        if (assetPath.Contains("_bumpmap"))
        {
            TextureImporter textureImporter = (TextureImporter)assetImporter;
            textureImporter.convertToNormalmap = true;
        }
    }

    //导入模型后事件
    void OnPostprocessModel(GameObject g)
    {
       
    }

    //导入贴图后事件
    void OnPostprocessTexture(Texture2D texture)
    {
    }

    //导入后所有资源事件
    static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths, bool didDomainReload)
    {
        // importedAssets:导入后所有的资源路径
        // deletedAssets:删除的所有的资源路径
        // movedAssets:移动的所有的资源路径
        // movedFromAssetPaths:移动前所有资源路径

        if (didDomainReload)
        {
            //代码修改后的重载事件
        }
    }
}
