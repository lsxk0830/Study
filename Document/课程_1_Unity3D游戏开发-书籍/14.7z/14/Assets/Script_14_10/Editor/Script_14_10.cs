using UnityEditor;
using UnityEngine;

//[CustomEditor(typeof(Camera))]
class Script_14_10 : Editor
{
	void OnSceneGUI()
	{
		Camera camera = target as Camera;
		if (camera != null)
		{
			Handles.color = Color.red;
			Handles.Label(camera.transform.position, camera.transform.position.
				ToString());

			Handles.BeginGUI();
			GUI.backgroundColor = Color.red;
			if (GUILayout.Button("click", GUILayout.Width(200f)))
			{
				Debug.LogFormat("click = {0}", camera.name);
			}
			GUILayout.Label("Label");
			Handles.EndGUI();
		}
	}
}
