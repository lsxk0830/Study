using UnityEditor;
using UnityEngine;

//[CustomEditor(typeof(Camera))]
public class Script_14_06 : CameraEditor
{
	public override void OnInspectorGUI()
	{
		if (GUILayout.Button("拓展按钮"))
		{
		}
		base.OnInspectorGUI();
	}
}
