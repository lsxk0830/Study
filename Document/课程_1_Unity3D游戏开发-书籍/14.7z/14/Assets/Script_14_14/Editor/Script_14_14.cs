using System;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

class Script_14_14 
{
    [InitializeOnLoadMethod]
    private static void InitializeOnLoad()
    {
        EditorApplication.delayCall += () =>
        {
            Type barType = typeof(Editor).Assembly.GetType("UnityEditor.Toolbar");
            var toolbars = Resources.FindObjectsOfTypeAll(barType);
            var toolbar = toolbars.Length > 0 ? (ScriptableObject)toolbars[0] : null;
            if (toolbar != null)
            {
                var root = toolbar.GetType().GetField("m_Root", BindingFlags.NonPublic | BindingFlags.Instance);
                var mRoot = root.GetValue(toolbar) as VisualElement;
                var toolbarZone = mRoot.Q("ToolbarZoneLeftAlign");
                var container = new IMGUIContainer();
                container.style.flexGrow = 1;
                container.onGUIHandler += OnGUI;
                toolbarZone.Add(container);
            }
        };
    }

    private static void OnGUI()
    {
        var rect = new Rect(360, 0, 60, 20);
        var space = 4;
        if (GUI.Button(rect, "按钮1"))
        {
            Debug.Log(1);
        }
        rect.x += rect.width + space;
        if (GUI.Button(rect, "按钮2"))
        {
        }
        rect.x += rect.width + space;
        if (GUI.Button(rect, "按钮3"))
        {
        }
    }
}
