using System.Reflection;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(RectTransform))]
public class Script_14_07 : Editor
{
	private Editor m_Editor;
	private void OnEnable()
    {
		m_Editor = CreateEditor(target,
					Assembly.GetAssembly(typeof(Editor)).GetType("UnityEditor.RectTransformEditor",true));
	}
	public override void OnInspectorGUI()
	{
		if (GUILayout.Button("拓展按钮"))
		{
		}
		m_Editor.OnInspectorGUI();
		//base.OnInspectorGUI();
	}


	[MenuItem("Script_14_07/GetName")]
	static void GetName()
    {
		//遍历内存中所有Editor对象
		foreach (var item in Resources.FindObjectsOfTypeAll<Editor>())
        {
			var go = item.target is Component;
			if (go && go == Selection.activeGameObject)
			{
				//并且Editor对象满足用户选择的游戏对象时输出名称
				Debug.Log(item.GetType());
			}
		}	
	}
}
