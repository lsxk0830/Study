using UnityEditor;
using UnityEngine;

class Script_14_15 
{
	[InitializeOnLoadMethod]
	static void InitializeOnLoadMethod()
	{
		Editor.finishedDefaultHeaderGUI += (editor) =>
		{
			if(editor.target is GameObject)
            {
				using (new EditorGUILayout.HorizontalScope())
                {
					GUILayout.Button("按钮1");
					GUILayout.Button("按钮2");
				}
            }
		};
	}
}
