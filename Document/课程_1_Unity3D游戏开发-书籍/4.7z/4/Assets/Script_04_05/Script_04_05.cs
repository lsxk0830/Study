using UnityEngine;
using UnityEngine.UI;

public class Script_04_05 : MonoBehaviour
{

    void Start()
    {
        GetComponent<ScrollRect>().onValueChanged.AddListener((progress) =>
        {
            //取值范围在0-1之间
            Debug.Log($"当前滚动进度{progress}");
        });
    }
}
