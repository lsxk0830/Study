using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Script_04_12 : MonoBehaviour,IPointerDownHandler, IPointerUpHandler
{
    public void OnPointerDown(PointerEventData eventData)
    {
        Debug.Log("按下事件");
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        Debug.Log("抬起事件");
    }
}
