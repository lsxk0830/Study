using UnityEngine;
using UnityEngine.U2D;
using System;

public class Script_04_11 : MonoBehaviour
{
    void OnEnable()
    {
        SpriteAtlasManager.atlasRequested += AtlasRequested;
        SpriteAtlasManager.atlasRegistered += AtlasRegistered;
    }

    void OnDisable()
    {
        SpriteAtlasManager.atlasRequested -= AtlasRequested;
        SpriteAtlasManager.atlasRegistered += AtlasRegistered;
    }

    void AtlasRequested(string atals, Action<SpriteAtlas> action)
    {
        Debug.Log($"{atals}加载开始加载");
        //通过Action将加载后的图集对象回调出去
        action(Resources.Load<SpriteAtlas>(atals));
    }
    void AtlasRegistered(SpriteAtlas atals)
    {
        Debug.Log($"{atals}加载完成");
    }
}
