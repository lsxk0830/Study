using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;
using static UnityEngine.Rendering.DebugUI;
using Slider = UnityEngine.UI.Slider;

public class Script_04_06 : MonoBehaviour
{
    public Slider Slider;
    public Scrollbar Scrollbar;
    public TMP_Dropdown TMP_Dropdown;
    public TMP_InputField TMP_InputField;


    void Start()
    {
        /*
        1.Slider
        设置Slider取值范围的最小值/最大值
        */
        Slider.minValue = 0;
        Slider.maxValue = 100;

        Slider.onValueChanged.AddListener((value)=>{
            Debug.Log($"Slider拖动变化值 = {value}");
        });

        /*
         2.Scrollbar
         */
        Scrollbar.onValueChanged.AddListener((value) => {
            Debug.Log($"Scrollbar滑动变化值 = {value}");
        });

        /*
         3.TMP_Dropdown
         */
        TMP_Dropdown.options = new List<TMP_Dropdown.OptionData>();
        TMP_Dropdown.options.Add(new TMP_Dropdown.OptionData() { text = "下拉框1" });
        TMP_Dropdown.options.Add(new TMP_Dropdown.OptionData() { text = "下拉框2" });
        TMP_Dropdown.options.Add(new TMP_Dropdown.OptionData() { text = "下拉框3" });
        TMP_Dropdown.onValueChanged.AddListener((index) =>
        {
            Debug.Log($"TMP_Dropdown下拉选择索引 = {index}");
        });

        /*
         4.TMP_InputField
           
         */

        TMP_InputField.onValueChanged.AddListener((str) =>
        {
            Debug.Log($"TMP_InputField 输入字符串中 = {str}");
        });
        TMP_InputField.onEndEdit.AddListener((str) =>
        {
            Debug.Log($"TMP_InputField 输入字符串结束 = {str}");
        });
        TMP_InputField.onEndTextSelection.AddListener((str, i, k) =>
        {
            Debug.Log($"TMP_InputField 鼠标框选字符串 = {str} 起始位置 = {i} 结束位置 = {k}" );
        });
        TMP_InputField.onDeselect.AddListener((str) =>
        {
            Debug.Log($"TMP_InputField 取消选字符串 = {str}");
        });
    }
}
