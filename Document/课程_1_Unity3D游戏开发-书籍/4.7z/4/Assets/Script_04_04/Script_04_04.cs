using UnityEngine;
using UnityEngine.UI;

public class Script_04_04 : MonoBehaviour
{
    public Toggle[] toogles;

    void Start()
    {
        foreach (var toogle in toogles)
        {
            toogle.onValueChanged.AddListener((selected)=> {
                Debug.LogFormat("toggle = {0} selected = {1}", toogle.name, selected);
            });
        }

    }
}
