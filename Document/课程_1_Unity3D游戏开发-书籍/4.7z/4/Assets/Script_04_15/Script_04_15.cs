using UnityEngine;
public class Script_04_15 : MonoBehaviour
{
    public GameObject Cube;
    private void Awake()
    {

        UGUIEventListener.Get(Cube).onClick += (go) =>
        {
            Debug.Log("模型点击事件");
        };
    }
}



