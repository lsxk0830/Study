using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using TMPro;

public class Script_04_13 : MonoBehaviour
{
    public Button Button1;
    public Button Button2;
    public TextMeshProUGUI Text;
    public Image Image;

    void Awake()
    {
        Button1.onClick.AddListener(delegate () {
            OnClick(Button1.gameObject);
        });

        Button2.onClick.AddListener(delegate () {
            OnClick(Button2.gameObject);
        });
        //对文本和Image进行监听
        UGUIEventListener.Get(Text.gameObject).onClick = OnClick;
        UGUIEventListener.Get(Image.gameObject).onClick = OnClick;
    }

    void OnClick(GameObject go)
    {
        if (go == Button1.gameObject)
        {
            Debug.Log("点击按钮1");
        }
        else if (go == Button2.gameObject)
        {
            Debug.Log("点击按钮2");
        }
        else if (go == Text.gameObject)
        {
            Debug.Log("点击文本框");
        }
        else if (go == Image.gameObject)
        {
            Debug.Log("点击图片");
        }
    }

}

public class UGUIEventListener : EventTrigger
{

    public UnityAction<GameObject> onClick;


    public override void OnPointerClick(UnityEngine.EventSystems.PointerEventData
        eventData)
    {
        base.OnPointerClick(eventData);

        if (onClick != null)
        {
            onClick(gameObject);
        }

    }

    ///<summary>
    ///获取或者添加UGUIEventListener脚本来实现对游戏对象的监听
    ///</summary>
    static public UGUIEventListener Get(GameObject go)
    {
        UGUIEventListener listener = go.GetComponent<UGUIEventListener>();
        if (listener == null)
            listener = go.AddComponent<UGUIEventListener>();
        return listener;
    }
}

