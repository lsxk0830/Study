using UnityEngine;
public class Script_04_16 : MonoBehaviour
{
    public GameObject Root;
    private void Awake()
    {
        Animation animation = Root.GetComponent<Animation>();
        animation.Play();
    }
}



