using UnityEngine;
using UnityEngine.UI;

public class Script_04_17 : ScrollRect
{
    protected float m_Radius = 0f;

    protected override void Start()
    {
        base.Start();
        //计算摇杆半径
        m_Radius = (transform as RectTransform).sizeDelta.x * 0.5f;
    }

    public override void OnDrag(UnityEngine.EventSystems.PointerEventData eventData)
    {
        base.OnDrag(eventData);
        var contentPostion = this.content.anchoredPosition;
        if (contentPostion.magnitude > m_Radius)
        {
            contentPostion = contentPostion.normalized * m_Radius;
            SetContentAnchoredPosition(contentPostion);
        }
    }
}



