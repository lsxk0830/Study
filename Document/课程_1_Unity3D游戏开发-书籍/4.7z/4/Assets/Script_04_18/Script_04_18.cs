using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Script_04_18 : MonoBehaviour,IPointerClickHandler
{
    void Start()
    {
        //当透明度小于0.1时不可点击
        GetComponent<Image>().alphaHitTestMinimumThreshold = 0.1f;
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        Debug.Log("click");
    }
}
