using UnityEngine;
using UnityEngine.UI;

public class EmptyImage : MaskableGraphic
{
    protected EmptyImage()
    {
        useLegacyMeshGeneration = true;
    }

    protected override void OnPopulateMesh(VertexHelper vh)
    {
        vh.Clear();
    }
}



