using UnityEngine;

public class Script_18_13 : MonoBehaviour
{
    public Color color = Color.white;
    void Awake()
    {
        Renderer renderer = GetComponent<Renderer>();
        MaterialPropertyBlock block = new MaterialPropertyBlock();

        renderer.GetPropertyBlock(block);
        block.SetColor("_Color", color);
        renderer.SetPropertyBlock(block);
    }
}
