using UnityEngine.UI;
using UnityEditor;
using UnityEngine;

public class Script_18_01 
{
    [MenuItem("Tools/Script_18_01")]
    static void Run()
    {
        GameObject bag_view = GameObject.Find("BagView");

        foreach (Transform trans in bag_view.GetComponentsInChildren<Transform>(true))
        {
            var name = trans.name;
            var split = name.Split("e_");
            if (split.Length>1)
            {
                var defineName = split[1];
                var defineType = GetType(trans);
                var definePath = AnimationUtility.CalculateTransformPath(trans, bag_view.transform);
                Debug.Log(defineName); //out: Button
                Debug.Log(defineType); //out: UnityEngine.UI.Button
                Debug.Log(definePath); //out: root/e_Button
            }
        } 
    }

    static string GetType(Transform trans)
    {
        if(trans.TryGetComponent<Button>(out Button button))
        {
            return button.GetType().ToString();
        }else if (trans.TryGetComponent<Image>(out Image image))
        {
            return image.GetType().ToString();
        }else if (trans.TryGetComponent<Text>(out Text text))
        {
            return text.GetType().ToString();
        }
        else
        {
            return trans.GetType().ToString();
        }
    }
}

