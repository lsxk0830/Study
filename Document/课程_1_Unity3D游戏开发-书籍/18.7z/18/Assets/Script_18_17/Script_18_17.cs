using UnityEngine;

public class Script_18_17 : MonoBehaviour
{
    public Texture2D[] sources;
    public Texture2D atlas;
    private void Start()
    {
        atlas = new Texture2D(1024, 1024,TextureFormat.ASTC_4x4,false);
        Rect[] rects = atlas.PackTextures(sources, 2, 1024);

        var mat = GetComponent<Renderer>().material;
        mat.SetTexture("_MainTex", atlas);

        Rect first = rects[0];
        mat.mainTextureOffset = new Vector2(first.x, first.y);
        mat.mainTextureScale = new Vector2(first.width, first.height);
    }
}
