using UnityEngine;

public class Script_18_04 : MonoBehaviour
{
    public Material material;
    public LazyLoadReference<Material> material2;


    private void Start()
    {
        //真正开始加载
        Material mat2 = material2.asset;

        Debug.Log(mat2.name);
    }
}


