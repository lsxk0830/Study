using UnityEngine;

public class Script_18_02 : MonoBehaviour
{
    void Start()
    {
        int32 i32 = new int32(100);

        //与各类型进行隐式转换
        int ii = i32 + 100 * 2000;
        float ff = i32;
        double dd = i32;

        //数据判断
        if (i32 == 10) { }
        if (i32 <= 10) { }

        //监听数据变化
        i32.valueChange += (change) => {
            Debug.Log(change);
        };

        //最终设置数值
        i32.value = 200;

        Debug.Log(i32);
    }

}


