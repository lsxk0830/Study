using System;

public struct int32 : IComparable, IFormattable, IComparable<int32>, IEquatable<int32>
{
    private int m_Value;
    public int value
    {
        get { return m_Value; }
        set
        {
            if (m_Value != value)
            {
                m_Value = value;
                valueChange?.Invoke(m_Value);
            }
        }
    }
    public Action<int> valueChange;
    public int32(int value)
    {
        valueChange = null;
        m_Value = value;
    }
    public static explicit operator byte(int32 value)
    {
        return (byte)value.value;
    }
    public static explicit operator sbyte(int32 value)
    {
        return (sbyte)value.value;
    }
    public static explicit operator short(int32 value)
    {
        return (short)value.value;
    }
    public static explicit operator ushort(int32 value)
    {
        return (ushort)value.value;
    }
    public static implicit operator int(int32 value)
    {
        return value.value;
    }
    public static explicit operator uint(int32 value)
    {
        return (uint)value.value;
    }
    public static implicit operator long(int32 value)
    {
        return value.value;
    }
    public static explicit operator ulong(int32 value)
    {
        return (ulong)value.value;
    }
    public static implicit operator float(int32 value)
    {
        return value.value;
    }
    public static implicit operator double(int32 value)
    {
        return value.value;
    }
    public static bool operator <(int32 lhs, int32 rhs)
    {
        return lhs.m_Value < rhs.m_Value;
    }
    public static bool operator <=(int32 lhs, int32 rhs)
    {
        return lhs.m_Value <= rhs.m_Value;
    }
    public static bool operator >(int32 lhs, int32 rhs)
    {
        return lhs.m_Value > rhs.m_Value;
    }
    public static bool operator >=(int32 lhs, int32 rhs)
    {
        return lhs.m_Value >= rhs.m_Value;
    }
    public int CompareTo(object obj)
    {
        return CompareTo(Convert.ToInt32(obj));
    }
    public override string ToString()
    {
        return m_Value.ToString();
    }
    public string ToString(string format)
    {
        return m_Value.ToString(format);
    }
    public string ToString(IFormatProvider provider)
    {
        return m_Value.ToString(provider);
    }
    public string ToString(string format, IFormatProvider provider)
    {
        return m_Value.ToString(format, provider);
    }
    public int CompareTo(int32 other)
    {
        if (m_Value == other.m_Value)
        {
            return 0;
        }
        else if (m_Value > other.m_Value)
        {
            return 1;
        }
        return -1;
    }
    public bool Equals(int32 other)
    {
        return m_Value == other.m_Value;
    }
}