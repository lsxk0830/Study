using System.Collections.Generic;
using UnityEngine;

public class Script_18_18 : MonoBehaviour
{
    public SkinnedMeshRenderer[] SMRs;
    public SkinnedMeshRenderer CombineSMR;
    private void Awake()
    {
        //遍历body身上的所有骨骼节点
        Dictionary<string, Transform> BoneHash = new Dictionary<string, Transform>();
        foreach (var trans in GetComponentsInChildren<Transform>(true))
        {
            BoneHash[trans.name] = trans;
        }

        List<CombineInstance> combineInstancesList = new List<CombineInstance>();
        List<Transform> bones = new List<Transform>();
        foreach (var smr in SMRs)
        {
            CombineInstance combine = new CombineInstance();
            combine.mesh = smr.sharedMesh;
            combine.transform = smr.localToWorldMatrix;
            combineInstancesList.Add(combine);

            foreach (var item in smr.bones)
            {
                string name = item.name;
                if(BoneHash.TryGetValue(name,out var trans))
                {
                    //body和head要合并，避免重复添加节点
                    bones.Add(trans);
                }
            } 

        }
        //合并网格
        Mesh mesh = new Mesh();
        mesh.CombineMeshes(combineInstancesList.ToArray(), true, true);

        //设置网格
        CombineSMR.sharedMesh = mesh;
        //设置骨骼节点
        CombineSMR.bones = bones.ToArray();
    }
}
