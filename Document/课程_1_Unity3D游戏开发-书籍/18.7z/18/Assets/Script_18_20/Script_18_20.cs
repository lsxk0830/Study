using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script_18_20 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        var ab = AssetBundle.LoadFromFile($"{Application.streamingAssetsPath}/Combine.ab", 0, 19835);
        Instantiate(ab.LoadAsset<GameObject>("Cube1.prefab"));

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
