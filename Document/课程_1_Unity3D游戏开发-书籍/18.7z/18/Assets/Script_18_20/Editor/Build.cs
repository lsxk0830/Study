using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

public class Build
{
    [MenuItem("Tools/Script_18_20")]
    static void BuildAB()
    {

        AssetBundleBuild[] build = new AssetBundleBuild[2];

        for (int i = 0; i < 2; i++)
        {
            build[i] = new AssetBundleBuild();
            build[i].assetNames = new string[] { $"Assets/Script_18_20/Cube{i}.prefab" };
            build[i].assetBundleName = $"Cube{i}.ab";
        }
        //打包AB文件
        BuildPipeline.BuildAssetBundles(Application.streamingAssetsPath, build, BuildAssetBundleOptions.None,
            BuildTarget.StandaloneOSX);

        //将两个AB文件合并成1个
        var srcArray1 = File.ReadAllBytes($"{Application.streamingAssetsPath}/Cube0.ab");
        Debug.Log(srcArray1.Length);//out: 19835
        var srcArray2 = File.ReadAllBytes($"{Application.streamingAssetsPath}/Cube1.ab");
        byte[] newArray = new byte[srcArray1.Length + srcArray2.Length];
        Array.Copy(srcArray1, 0, newArray, 0, srcArray1.Length);
        Array.Copy(srcArray2, 0, newArray, srcArray1.Length, srcArray2.Length);

        File.WriteAllBytes($"{Application.streamingAssetsPath}/Combine.ab", newArray);
    }
}

