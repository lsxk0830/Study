using UnityEngine;

public class Script_18_07 : MonoBehaviour
{
    GameObject m_Asset;
    private void Awake()
    {
        m_Asset =  Assets.Load<GameObject>("Assets/Script_18_07/Cube.prefab");
    }
    private void OnGUI()
    {
        if (GUILayout.Button("<size=100>GC</size>"))
        {
            m_Asset = null;
            System.GC.Collect(0);
            Resources.UnloadUnusedAssets();
            Assets.GC();
        }
       
        GUILayout.Label($"<size=100>Count:{Assets.s_CacheAsset.Count}</size>");
    }
}

