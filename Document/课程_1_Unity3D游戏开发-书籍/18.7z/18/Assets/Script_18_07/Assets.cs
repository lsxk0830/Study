using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;

public class Assets
{
    //根据资源名保存Assetbundle文件
    static public Dictionary<string, string> s_NameForAB = new Dictionary<string, string>();
    //根据Assetbundle文件名缓存AssetBundle对象
    static public Dictionary<string, AssetBundle> s_CacheAB = new Dictionary<string, AssetBundle>();
    //记录资源名和弱引用的关系
    static public Dictionary<string, WeakReference> s_CacheAsset = new Dictionary<string, WeakReference>();

    static public T Load<T>(string name) where T : UnityEngine.Object
    {
        T o = null;
#if UNITY_EDITOR
        o= AssetDatabase.LoadAssetAtPath<T>(name);
#else
        if (s_NameForAB.TryGetValue(name,out var abName))
        {
            AssetBundle ab;
            if (!s_CacheAB.TryGetValue(abName,out ab))
            {
                ab = AssetBundle.LoadFromFile(abName);
                s_CacheAB[abName] = ab;
            }
            o= ab.LoadAsset<T>(name);
        }
#endif
        if (o != null)
        {
          
            if (!s_CacheAsset.ContainsKey(name))
            {
                s_CacheAsset[name] = new WeakReference(o,false);
            }
        }

        return o;
    }

    static public void GC()
    {
        List<string> removals = new List<string>();
        foreach (var item in s_CacheAsset)
        {
            WeakReference weak = item.Value;
            if (!weak.IsAlive)
            {
                //引用已经断开，可以清理资源
                removals.Add(item.Key);
            }
        }
        for (int i = removals.Count-1; i >= 0; i--)
        {
            string assetName = removals[i];
            if (s_NameForAB.TryGetValue(assetName, out var abName))
            {
                if (s_CacheAB.TryGetValue(abName, out AssetBundle ab))
                {
                    //释放AB对象，清空缓存
                    ab.Unload(true);
                    s_CacheAB.Remove(abName);
                }
            }
            s_CacheAsset.Remove(assetName);
        }
    }
}
