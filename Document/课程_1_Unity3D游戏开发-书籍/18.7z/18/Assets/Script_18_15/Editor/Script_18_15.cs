using UnityEngine;
using UnityEditor;
using System;
using System.IO;

public class Script_18_15
{

    [MenuItem("Tools/Script_18_15")]
    static void Combine()
    {
        Texture2D tex512 = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Script_18_15/512.jpg");
        Texture2D tex256 = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Script_18_15/256.jpg");
        Texture2D @out = Combine(
            new[] { tex512, tex256 }, //贴图
            new[] { (0, 0), (512, 512) } //偏移
            , 1024);//最终贴图大小

        File.WriteAllBytes("Assets/Script_18_15/1024.jpg", @out.EncodeToJPG());
        AssetDatabase.Refresh();
    }

    static Texture2D Combine(Texture2D[] texs, ValueTuple<int, int>[] offests, int size)
    {
        Texture2D @out = new Texture2D(size, size, TextureFormat.RGBA32, true);
        for (int i = 0; i < texs.Length; i++)
        {
            var tex = texs[i];
            var offest = offests[i];
            var width = tex.width;
            var height = tex.height;
            RenderTexture tmp = RenderTexture.GetTemporary(width, height, 0, RenderTextureFormat.Default, RenderTextureReadWrite.Linear);
            Graphics.Blit(tex, tmp);
            RenderTexture previous = RenderTexture.active;
            RenderTexture.active = tmp;
            Texture2D @new = new Texture2D(width, height);
            @new.ReadPixels(new Rect(0, 0, width, height), 0, 0);
            @new.Apply();
            @out.SetPixels(offest.Item1, offest.Item2, width, height, @new.GetPixels());
            RenderTexture.active = previous;
            RenderTexture.ReleaseTemporary(tmp);
        }
        return @out;
    }
}
