using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif
public class Script_18_19 : MonoBehaviour
{
#if UNITY_EDITOR
    [InitializeOnLoadMethod]
    static void InitializeOnLoadMethodFun()
    {
        Selection.selectionChanged += Change;
        EditorApplication.hierarchyChanged += Change;
    }

    static void Change()
    {
        var active = Selection.activeGameObject;
        if (active && !IsInPrefabStage())
        {
            Script_18_19 parent = active.GetComponentInParent<Script_18_19>();
            if (parent)
            {
                foreach (var trans in parent.GetComponentsInChildren<Transform>(true))
                {
                    trans.gameObject.hideFlags = HideFlags.NotEditable | HideFlags.DontSave;
                }
            }
        }
    }

    static bool IsInPrefabStage()
    {
        return UnityEditor.SceneManagement.PrefabStageUtility.GetCurrentPrefabStage() != null; ;
    }
#endif
}


