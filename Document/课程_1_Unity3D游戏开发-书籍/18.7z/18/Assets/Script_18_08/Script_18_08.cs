using UnityEditor;
using UnityEngine;

[CreateAssetMenu(fileName ="Pack",menuName ="资源/打包配置")]
public class Script_18_08 : ScriptableObject
{
    public enum Type 
    {
        [InspectorName("目录打包")]
        EVERY_DIR=0,
        [InspectorName("文件打包")]
        EVENT_FILE
    }

    public string PackName;
#if UNITY_EDITOR
    public DefaultAsset DefaultAsset;
#endif
    public string Extension;
    public Type PackType = Type.EVERY_DIR;
}

