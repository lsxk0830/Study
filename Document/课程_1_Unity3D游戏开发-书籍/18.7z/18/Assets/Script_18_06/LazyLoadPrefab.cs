#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;

public class LazyLoadPrefab : MonoBehaviour
{
    ///--------序列化信息面板-------- 
    [SerializeField]
    private string m_LoadPath = string.Empty;
    ///--------序列化信息面板-------- 

    void Awake()
    {
        Load();
    }

    ///<summary>
    ///加载资源
    ///</summary>
    public void Load()
    {
        //清空节点
        if (transform != null)
        {
            while (transform.childCount > 0)
            {
                DestroyImmediate(transform.GetChild(0).gameObject);
            }
        }

        GameObject prefab = Resources.Load<GameObject>(m_LoadPath);
        if (prefab)
        {
            GameObject go = Instantiate<GameObject>(prefab);
            go.transform.SetParent(transform, false);
            go.name = prefab.name;
            go.SetActive(true);
#if UNITY_EDITOR
            foreach (Transform t in go.GetComponentsInChildren<Transform>()) {
				t.gameObject.hideFlags = HideFlags.NotEditable | HideFlags.DontSave;
			}
#endif
        }
    }
 
}

#if UNITY_EDITOR
[CustomEditor(typeof(LazyLoadPrefab))]
public class LazyLoadPrefabEditor : Editor
{
    void OnEnable()
    {
        if (target != null)
        {
            if (!Application.isPlaying)
            {
                (target as LazyLoadPrefab).Load();
            }
        }
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        GUILayout.Label("请把Resources目录下的Prefab拖入");
        string loadPath = serializedObject.FindProperty("m_LoadPath").stringValue;
        EditorGUI.BeginChangeCheck();
        GameObject prefab = Resources.Load<GameObject>(loadPath);
        GameObject newPrefab = EditorGUILayout.ObjectField("Prefab", prefab,
            typeof(GameObject)) as GameObject;
        if (EditorGUI.EndChangeCheck())
        {

            serializedObject.FindProperty("m_LoadPath").stringValue = newPrefab.name;

            serializedObject.ApplyModifiedProperties();
            if (!Application.isPlaying)
            {
                (target as LazyLoadPrefab).Load();
            }
        }
        GUILayout.Space(18f);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Refresh", GUILayout.Width(80)))
        {
            (target as LazyLoadPrefab).Load();
        }
        GUILayout.EndHorizontal();
        serializedObject.ApplyModifiedProperties();
    }
}
#endif