using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LazyLoadImage : Image
{
    public string spriteName;
    public string materialName;
    protected override void OnEnable()
    {
        //根据精灵名称异步加载
    }
}
