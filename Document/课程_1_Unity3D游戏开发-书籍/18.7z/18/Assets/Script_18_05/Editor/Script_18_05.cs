using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public class Script_18_05 : MonoBehaviour
{
    [MenuItem("Tools/Script_18_05")]
    static void Run()
    {
        string bag_View = "Assets/Script_18_05/BagView.prefab";
        string bag_View_copy = "Assets/Script_18_05/BagView_Copy.prefab";

        var bag_view_asset = AssetDatabase.LoadAssetAtPath<GameObject>(bag_View);
        var bag_view_go = GameObject.Instantiate<GameObject>(bag_view_asset);

        foreach (var image in bag_view_go.GetComponentsInChildren<Image>(true))
        {
            //记录属性
            var spritename = (image.sprite!=null)? image.sprite.name : "";
            var go = image.gameObject;
            //删除组件
            GameObject.DestroyImmediate(image);
            //还原组件
            var lazy= go.AddComponent<LazyLoadImage>();
            lazy.spriteName = spritename;
        }

        PrefabUtility.SaveAsPrefabAsset(bag_view_go, bag_View_copy);
        GameObject.DestroyImmediate(bag_view_go);
        AssetDatabase.Refresh();
    }
}


