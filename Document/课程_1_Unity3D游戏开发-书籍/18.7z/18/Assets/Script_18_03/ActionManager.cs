using System;
using System.Collections.Generic;

public class ActionManager
{
    Dictionary<object, object> m_Actions = new Dictionary<object, object>();

    public NewAction RegAction(NewAction newAction, Action action)
    {
        newAction += action;
        m_Actions[newAction] = action;
        return newAction;
    }
    public NewAction<T1> RegAction<T1>(NewAction<T1> newAction, Action<T1> action)
    {
        newAction += action;
        m_Actions[newAction] = action;
        return newAction;
    }
    public NewFunc<T1> RegAction<T1>(NewFunc<T1> newAction, Func<T1> action)
    {
        newAction += action;
        m_Actions[newAction] = action;
        return newAction;
    }
    public NewFunc<T1, T2> RegAction<T1, T2>(NewFunc<T1, T2> newAction, Func<T1, T2> action)
    {
        newAction += action;
        m_Actions[newAction] = action;
        return newAction;
    }

    public void Clear()
    {
        foreach (var act in m_Actions)
        {
            ((IAction)act.Key).Dispose(act.Value);
        }
    }
}

public interface IAction
{
    void Dispose(object obj);
}
public class NewAction : IAction
{
    Action action;
    public void Dispose(object obj)
    {
        if (obj is Action act)
            action -= act;
    }
    public void Invoke()
    {
        action?.Invoke();
    }
    public static NewAction operator +(NewAction a, Action b)
    {
        a.action -= b;
        a.action += b;
        return a;
    }
    public static NewAction operator -(NewAction a, Action b)
    {
        a.action -= b;
        return a;
    }
}
public class NewAction<T1> : IAction
{
    Action<T1> action;
    public void Dispose(object obj)
    {
        if (obj is Action<T1> act)
            action -= act;
    }
    public void Invoke(T1 t1)
    {
        action?.Invoke(t1);
    }
    public static NewAction<T1> operator +(NewAction<T1> a, Action<T1> b)
    {
        a.action -= b;
        a.action += b;
        return a;
    }
    public static NewAction<T1> operator -(NewAction<T1> a, Action<T1> b)
    {
        a.action -= b;
        return a;
    }
}
public class NewFunc<T1> : IAction
{
    Func<T1> func;
    public void Dispose(object obj)
    {
        if (obj is Func<T1> act)
            func -= act;
    }
    public T1 Invoke()
    {
        return func != null ? func.Invoke() : default(T1);
    }
    public static NewFunc<T1> operator +(NewFunc<T1> a, Func<T1> b)
    {
        a.func -= b;
        a.func += b;
        return a;
    }
    public static NewFunc<T1> operator -(NewFunc<T1> a, Func<T1> b)
    {
        a.func -= b;
        return a;
    }
}
public class NewFunc<T1, T2> : IAction
{
    Func<T1, T2> func;
    public void Dispose(object obj)
    {
        if (obj is Func<T1, T2> act)
            func -= act;
    }
    public T2 Invoke(T1 t1)
    {
        return func != null ? func.Invoke(t1) : default(T2);
    }
    public static NewFunc<T1, T2> operator +(NewFunc<T1, T2> a, Func<T1, T2> b)
    {
        a.func -= b;
        a.func += b;
        return a;
    }
    public static NewFunc<T1, T2> operator -(NewFunc<T1, T2> a, Func<T1, T2> b)
    {
        a.func -= b;
        return a;
    }
}