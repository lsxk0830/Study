using UnityEngine;

public class Script_18_03 : MonoBehaviour
{
    public class BaseBagView
    {
        //...部分生成代码略
        protected ActionManager m_ActionManager = new ActionManager();

        protected virtual void Open() { }
        protected virtual void Close()
        {
            //界面关闭时父类清空所有事件
            m_ActionManager.Clear();
        }
    }

    //手写代码
    public class BagView : BaseBagView
    {
        NewAction<string> MyAction = new NewAction<string>();//事件需要new
        NewFunc<string, int> MyFunc = new NewFunc<string, int>();//事件需要new

        public void MyFunction(string str)
        {
            Debug.Log(" MyFunction  " + str);
        }
        public int MyFunction1(string str)
        {
            Debug.Log(" MyFunction1  " + str);
            return 1;
        }

        protected override void Open()
        {
            base.Open();
            //监听事件
            m_ActionManager.RegAction(MyAction, MyFunction);
            m_ActionManager.RegAction(MyFunc, MyFunction1);

            //抛出参数
            MyAction.Invoke("参数1");
            MyFunc.Invoke("参数2");
        }
    }
}


