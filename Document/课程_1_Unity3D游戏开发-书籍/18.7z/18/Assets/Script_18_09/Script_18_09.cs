using System.Collections.Generic;
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;
using System.IO;
public class Script_18_09 : MonoBehaviour
{
    Dictionary<string, string> m_NameHash = new Dictionary<string, string>();
    void Start()
    {
#if UNITY_EDITOR
        foreach (var guid in AssetDatabase.FindAssets("t:Script_18_08"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            var pack = AssetDatabase.LoadAssetAtPath<Script_18_08>(path);
            var dir = AssetDatabase.GetAssetPath(pack.DefaultAsset);
            var ext = pack.Extension;
            foreach (var item in Directory.GetFiles(dir, $"*{ext}"))
            {
                var name = Path.GetFileName(item);
                m_NameHash[name] = item;
            } 
        }
        Debug.Log(m_NameHash["Cube.prefab"]); //out:Assets/Script_18_08/Cube.prefab
#endif
    }
}
